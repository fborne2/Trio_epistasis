import os
from Bio import SeqIO
from Bio.Seq import Seq

folder = "."  # folder with your DNA FASTA files
output_folder = "translated_OG"
os.makedirs(output_folder, exist_ok=True)

for fname in os.listdir(folder):
    if fname.endswith(".fasta"):
        input_path = os.path.join(folder, fname)
        output_path = os.path.join(output_folder, fname.replace(".fasta", "_translated.fasta"))

        records = []
        total_count = 0

        for record in SeqIO.parse(input_path, "fasta"):
            total_count += 1
            dna_seq = str(record.seq).upper()
            try:
                # Translate normally
                protein_seq = Seq(dna_seq).translate(to_stop=False)
            except Exception:
                # Replace any invalid codons with 'X'
                protein_seq = ""
                for i in range(0, len(dna_seq), 3):
                    codon = dna_seq[i:i+3]
                    if len(codon) < 3:
                        break
                    try:
                        protein_seq += str(Seq(codon).translate(to_stop=False))
                    except Exception:
                        protein_seq += "X"
                protein_seq = Seq(protein_seq)

            record.seq = protein_seq
            records.append(record)

        SeqIO.write(records, output_path, "fasta")
        print(f"{fname}: translated {len(records)} / {total_count} sequences")

print("All sequences translated, N codons become X in protein sequences.")

