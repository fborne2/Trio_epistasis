#!/bin/bash
#Usage:
#sbatch --account=palab --mem=200000 --ntasks-per-node=32 run_Andrew_consensus.sh FBtr0310080_2

cd /burg/palab/users/fb2589/MASS-PRF/clone_20230329/MASSPRF/bin

transcript=$1 #name of the transcript with number of the piece when split

./massprf -ic 1 -sn 83 -p /burg/palab/users/fb2589/Andrew_CDS/mel_sim_yak_alignments/combined_fasta/macse_output/no_gaps/consensus/consensus_split/batch4/$transcript"_polymorphism_consensus.txt" -d /burg/palab/users/fb2589/Andrew_CDS/mel_sim_yak_alignments/combined_fasta/macse_output/no_gaps/consensus/consensus_split/batch4/$transcript"_divergence_consensus.txt" -o 1  -r 1 -ci_r 1 -ci_m 1 -s 1 -exact 0 -mn 30000 -t 2.5 >/burg/palab/users/fb2589/Andrew_CDS/mel_sim_yak_alignments/combined_fasta/macse_output/no_gaps/consensus/consensus_split/batch4/$transcript"_MASS-PRF_BIC.txt"
